package com.example.expenseapp

class DataClassByMonth {

    var monthName: String = ""
    var monthAmount: String =  ""

}
