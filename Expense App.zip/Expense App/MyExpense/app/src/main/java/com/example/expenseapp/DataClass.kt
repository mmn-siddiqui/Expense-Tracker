package com.example.expenseapp

import java.io.Serializable

class DataClass : Serializable{

    var id:String = ""
    var expenseName: String = ""
    var expenseAmount: String = ""
    var expenseDate: String = ""

}